import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
Fs, y_initial = wavfile.read('./Kuusi.wav')

y = y_initial.astype(np.float64)
y_mean_removed = y - np.mean(y)
y = y_mean_removed / np.max(np.abs(y_mean_removed))

duration = len(y) / Fs
time = np.linspace(0, duration, len(y))


plt.plot(time, y, label='Normalized Signal', color='green', linewidth=0.5)
plt.title('Normalized Audio Signal')
plt.ylabel('Amplitude')
plt.grid(axis='y', linestyle='--')
plt.ylim(-1.1, 1.1)
plt.xlim(0, duration)
plt.show()
