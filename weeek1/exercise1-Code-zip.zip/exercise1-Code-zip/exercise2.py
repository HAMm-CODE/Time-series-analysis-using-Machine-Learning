import librosa
import soundfile as sf
import matplotlib.pyplot as plt
import librosa.display

y, sr = librosa.load('Kuusi.wav', sr=8000)

y_2000 = librosa.resample(y, orig_sr=sr, target_sr=2000)
sf.write('Kuusi_2000Hz.wav', y_2000, 2000)

y_1000 = librosa.resample(y, orig_sr=sr, target_sr=1000)
sf.write('Kuusi_1000Hz.wav', y_1000, 1000)

y_500 = librosa.resample(y, orig_sr=sr, target_sr=500)
sf.write('Kuusi_500Hz.wav', y_500, 500)

y_250 = librosa.resample(y, orig_sr=sr, target_sr=250)
sf.write('Kuusi_250Hz.wav', y_250, 250)


plt.figure(figsize=(10, 6))

plt.subplot(4,1,1)
librosa.display.waveshow(y_2000, sr=2000)
plt.title('Resampled at 2000 Hz')

plt.subplot(4,1,2)
librosa.display.waveshow(y_1000, sr=1000)
plt.title('Resampled at 1000 Hz')

plt.subplot(4,1,3)
librosa.display.waveshow(y_500, sr=500)
plt.title('Resampled at 500 Hz')

plt.subplot(4,1,4)
librosa.display.waveshow(y_250, sr=250)
plt.title('Resampled at 250 Hz')
plt.xlabel('Time (s)')

plt.tight_layout()
plt.show()
