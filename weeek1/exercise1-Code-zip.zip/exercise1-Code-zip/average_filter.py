#Jari Turunen, TUNI
import numpy as np
from numpy import cos, sin, pi, absolute, arange, mean
from matplotlib import pyplot as plt
from scipy.stats import skew, kurtosis


fs = 8000     
freq = 440    
end_time = 0.1
time = np.arange(0, end_time, 1/fs)  
print(len(time))


y = sin(2*pi*freq*time) + np.random.normal(loc=0.0, scale=0.8, size=[1, len(time)]) 
y = y.squeeze()
print(y.shape)


len1 = 4  
len2 = 10 
x = y.copy()*0
x2 = y.copy()*0
x3 = y.copy()*0
x4 = y.copy()*0

for i in range(len(y)):
    print("%d / %d\n" % (i, len(y)))
    start = i - len1
    if start < 1:
        start = 1
    start2 = i - len2
    if start2 < 1:
        start2 = 1

    ending = i + len1    
    if ending > len(y):
        ending = len(y)
    ending2 = i + len2    
    if ending2 > len(y):
        ending2 = len(y)

    if len(y[start:ending]) < 2:
        x[i] = 0
    else:
        x[i] = np.mean(y[start:ending])  
    if len(y[start2:ending2]) < 2:
        x2[i] = 0
    else:
        x2[i] = np.mean(y[start2:ending2]) 
        x3[i] = skew(y[start2:ending2], axis=0, bias=True)
        x4[i] = kurtosis(y[start2:ending2], axis=0, bias=True)

plt.figure(figsize=(10,5))
plt.plot(y)
plt.plot(x, 'r')
plt.plot(x2, 'g')
plt.plot(x3, 'b')
plt.plot(x4, 'y')
plt.legend(['Original', str(len1*2+1)+'-sample filtered', str(len2*2+1)+'-sample filtered'])
plt.title("Signal and Windowed Means/Statistics")
plt.show()


def energy_curve(signal, window):
    en = np.zeros(len(signal))
    half_win = window // 2
    for i in range(len(signal)):
        start = max(0, i - half_win)
        end = min(len(signal), i + half_win)
        segment = signal[start:end]
        en[i] = np.sum((segment - np.mean(segment))**2)
    return en


E1 = energy_curve(y, 5)
E2 = energy_curve(y, 50)
E3 = energy_curve(y, 200)

plt.figure(figsize=(10,6))
plt.subplot(2,1,1)
plt.plot(time, y, color='gray')
plt.title("Original Noisy Signal")

plt.subplot(2,1,2)
plt.plot(time, E1, label="Window=5 (less smooth)")
plt.plot(time, E2, label="Window=50 (moderate smooth)")
plt.plot(time, E3, label="Window=200 (very smooth)")
plt.xlabel("Time (s)")
plt.ylabel("Energy")
plt.title("Energy Curve vs. Window Size (Smoothness)")
plt.legend()
plt.tight_layout()
plt.show()

