import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


data = pd.read_pickle("AMZN.pkl")  
print(data.head())                 
y = data['Open'].values            
time = np.arange(len(y))           


def energy_curve(signal, window):
    en = np.zeros(len(signal))
    half_win = window // 2
    for i in range(len(signal)):
        start = max(0, i - half_win)
        end = min(len(signal), i + half_win)
        segment = signal[start:end]
        en[i] = np.sum((segment - np.mean(segment))**2)
    return en


E_small = energy_curve(y, 5)
E_medium = energy_curve(y, 30)
E_large = energy_curve(y, 100)

plt.figure(figsize=(12,6))

plt.subplot(2,1,1)
plt.plot(time, y, color='gray')
plt.title("Amazon Stock 'Open' Price Fluctuations")

plt.subplot(2,1,2)
plt.plot(time, E_small, label='Window=5')
plt.plot(time, E_medium, label='Window=30')
plt.plot(time, E_large, label='Window=100')
plt.xlabel("Time (days)")
plt.ylabel("Energy")
plt.title("Energy Curve Smoothness for Different Window Sizes")
plt.legend()
plt.tight_layout()
plt.show()